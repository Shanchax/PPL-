#include <iostream>

using namespace std;

int main ()
{

    class animal
    {
    public:
        int legs, eyes;
    public:
        animal (int a = 4, int b = 2)
        {
            legs = a;
            eyes = b;
        }
    };

    class wild_animals:public animal
    {
    public:
        void place ()
        {
            cout << "Lives in forest" << "\n";
        }
    };

    class carnivores:public wild_animals
    {
    public:
        void food ()
        {
            cout << "Eats meat" << "\n";
        }
    };

    class bear:public carnivores
    {
    public:
        void sound ()
        {

            cout << "It growls" << "\n";
        }

        void colour ()
        {

            cout << "It's colour is orange with black stripes" << "\n";
        }

        void young_ones ()
        {

            cout << "IT's young one is called as cub" << "\n";
        }
    };

    class tiger:public carnivores
    {
    public:
        void sound ()
        {

            cout << "It roars" << "\n";
        }

        void colour ()
        {

            cout << "It's colour brown or white" << "\n";
        }

        void young_ones ()
        {

            cout << "IT's young one is called as cub" << "\n";
        }
    };

    class falcons:public carnivores
    {
    public:
        void sound ()
        {

            cout << "It shreiks or whistles" << "\n";
        }

        void colour ()
        {

            cout << "It's colour dark or gray" << "\n";
        }

        void young_ones ()
        {

            cout << "IT's young one is called as eyas" << "\n";
        }
    };

    class herbivores:public wild_animals
    {
    public:
        void food ()
        {
            cout << "Eats grass and fruits" << "\n";
        }

    };

    class cow:public herbivores
    {
    public:
        void sound ()
        {

            cout << "It moos" << "\n";
        }

        void colour ()
        {

            cout << "Many colours such as black and brown" << "\n";
        }

        void young_ones ()
        {

            cout << "IT's young one is called as calf" << "\n";
        }
    };

    class rabbit:public herbivores
    {
    public:
        void sound ()
        {

            cout << "It squeks or grunts" << "\n";
        }

        void colour ()
        {

            cout << "Many colours such as black and white" << "\n";
        }

        void young_ones ()
        {

            cout << "IT's young one is called as calf" << "\n";
        }
    };

    class woodpeckers:public herbivores
    {
    public:
        void sound ()
        {

            cout << "It shrills" << "\n";
        }

        void colour ()
        {

            cout << "Many colours such as black and red" << "\n";
        }

        void young_ones ()
        {

            cout << "IT's young one is called as chick" << "\n";
        }
    };

    tiger t1;

    cout << t1.eyes << "\n" << t1.legs << "\n";
    t1.colour ();
    t1.young_ones ();
    t1.sound ();
    t1.food ();
    t1.place ();
    return 0;
}
