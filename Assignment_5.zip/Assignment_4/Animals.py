
class animal():
    def __init__(self, legs=4, eyes=2):
        self.legs = legs
        self.eyes = eyes

class wild_animals(animal):
    def place(sself):
        print("Lives in forest")
        
class carnivores(wild_animals):
    def food(self):
        print("Eats meat")
        
class bear(carnivores):
    def sound(self):
        print("It growls")
    def colour(self):
        print("It's colour is orange with black stripes")
    def young_ones(self):
        print("IT's young one is called as cub")
    
class tiger(carnivores):
    def sound(self):
        print("It roars")
    def colour(self):
        print("It's colour is brown or white")
    def young_ones(self):
        print("It's young one is called as cub")
        
class falcons(carnivores):
    def sound(self):
        print("It shrieks or whistles")
    def colour(self):
        print("It's colour is dark grey")
    def young_ones(self):
        print("It's young one is called as eyas")
        
        
        
class herbivores(wild_animals):
    def food(self):
        print("Eats grass and fruits")
        
class cow(herbivores):
    def sound(self):
        print("It moos")
    def colour(self):
        print("Many colours such as black and brown")
    def young_ones(self):
        print("It's young one is called as calf")
        
class rabbit(herbivores):
     def sound(self):
        print("It squeks or grunts")
     def colour(self):
        print("Many colours such as brown and white")
     def young_ones(self):
        print("It's young one is called as bunny")
               
class woodpeckers(herbivores):
     def sound(self):
        print("It shrills")
     def colour(self):
        print("Many colours such as black and red")
     def young_ones(self):
        print("It's young one is called as chick")

        
